#!/usr/bin/env python3
"""
MediaPipe landmark detection module for MediaPipe to Blender live animation add-on.
This module handles detection of face, hand, and body landmarks using MediaPipe.
"""

import cv2
import mediapipe as mp
import numpy as np
import time
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field

# Import video capture module
from .video_capture import VideoCapture, get_video_manager


@dataclass
class LandmarkData:
    """Data class for storing landmark information."""
    landmarks: List[Dict[str, float]]  # List of landmarks with x, y, z coordinates
    world_landmarks: Optional[List[Dict[str, float]]] = None  # 3D world landmarks if available
    visibility: Optional[List[float]] = None  # Visibility scores for landmarks
    timestamp: float = 0.0  # Timestamp in milliseconds
    detection_confidence: float = 0.0  # Confidence score for the detection
    tracking_id: Optional[int] = None  # Tracking ID for the detection


@dataclass
class FaceData(LandmarkData):
    """Data class for storing face landmark information."""
    blendshapes: Optional[List[Dict[str, float]]] = None  # Facial expression blendshapes


@dataclass
class HandData(LandmarkData):
    """Data class for storing hand landmark information."""
    handedness: str = "UNKNOWN"  # LEFT or RIGHT
    hand_flag: int = 0  # 0 for left, 1 for right


@dataclass
class PoseData(LandmarkData):
    """Data class for storing pose landmark information."""
    segmentation_mask: Optional[np.ndarray] = None  # Segmentation mask if available


@dataclass
class DetectionResult:
    """Data class for storing detection results from all MediaPipe models."""
    faces: List[FaceData] = field(default_factory=list)
    hands: List[HandData] = field(default_factory=list)
    pose: List[PoseData] = field(default_factory=list)
    frame_timestamp: float = 0.0
    frame_index: int = 0
    source_dimensions: Tuple[int, int] = (0, 0)  # (width, height)


class MediaPipeDetector:
    """
    Base class for MediaPipe detectors.
    Provides common functionality for all detector types.
    """
    
    def __init__(self, min_detection_confidence: float = 0.5, min_tracking_confidence: float = 0.5):
        """
        Initialize the detector with specified parameters.
        
        Args:
            min_detection_confidence: Minimum confidence for detection to be considered successful
            min_tracking_confidence: Minimum confidence for tracking to be considered successful
        """
        self.min_detection_confidence = min_detection_confidence
        self.min_tracking_confidence = min_tracking_confidence
        self.detector = None
        self.is_initialized = False
        
        # Performance metrics
        self.process_times = []
        self.max_process_times = 30  # Keep track of last 30 processing times
        
        # Drawing utilities
        self.mp_drawing = mp.solutions.drawing_utils
    
    def initialize(self) -> bool:
        """
        Initialize the detector.
        Must be implemented by subclasses.
        
        Returns:
            bool: True if initialization was successful, False otherwise
        """
        raise NotImplementedError("Subclasses must implement initialize()")
    
    def process_frame(self, frame: np.ndarray, timestamp_ms: float) -> Any:
        """
        Process a frame with the detector.
        Must be implemented by subclasses.
        
        Args:
            frame: Input frame as numpy array
            timestamp_ms: Timestamp of the frame in milliseconds
            
        Returns:
            Any: Detection results
        """
        raise NotImplementedError("Subclasses must implement process_frame()")
    
    def draw_landmarks(self, frame: np.ndarray, results: Any) -> np.ndarray:
        """
        Draw landmarks on the frame.
        Must be implemented by subclasses.
        
        Args:
            frame: Input frame as numpy array
            results: Detection results from process_frame()
            
        Returns:
            np.ndarray: Frame with landmarks drawn
        """
        raise NotImplementedError("Subclasses must implement draw_landmarks()")
    
    def get_average_process_time(self) -> float:
        """
        Get the average processing time in milliseconds.
        
        Returns:
            float: Average processing time in milliseconds
        """
        if not self.process_times:
            return 0.0
        return sum(self.process_times) / len(self.process_times)
    
    def close(self) -> None:
        """Release resources used by the detector."""
        if hasattr(self, 'detector') and self.detector is not None:
            if hasattr(self.detector, 'close'):
                self.detector.close()
            self.detector = None
        self.is_initialized = False


class FaceDetector(MediaPipeDetector):
    """
    MediaPipe face landmark detector.
    Detects facial landmarks and expressions.
    """
    
    def __init__(
        self, 
        min_detection_confidence: float = 0.5, 
        min_tracking_confidence: float = 0.5,
        max_num_faces: int = 1,
        output_face_blendshapes: bool = True,
        refine_landmarks: bool = True
    ):
        """
        Initialize the face detector with specified parameters.
        
        Args:
            min_detection_confidence: Minimum confidence for detection to be considered successful
            min_tracking_confidence: Minimum confidence for tracking to be considered successful
            max_num_faces: Maximum number of faces to detect
            output_face_blendshapes: Whether to output face blendshapes
            refine_landmarks: Whether to refine landmarks (includes eye and lip landmarks)
        """
        super().__init__(min_detection_confidence, min_tracking_confidence)
        self.max_num_faces = max_num_faces
        self.output_face_blendshapes = output_face_blendshapes
        self.refine_landmarks = refine_landmarks
        
        # MediaPipe face mesh solution
        self.mp_face_mesh = mp.solutions.face_mesh
        self.mp_drawing_styles = mp.solutions.drawing_styles
    
    def initialize(self) -> bool:
        """
        Initialize the face detector.
        
        Returns:
            bool: True if initialization was successful, False otherwise
        """
        try:
            self.detector = self.mp_face_mesh.FaceMesh(
                static_image_mode=False,
                max_num_faces=self.max_num_faces,
                refine_landmarks=self.refine_landmarks,
                min_detection_confidence=self.min_detection_confidence,
                min_tracking_confidence=self.min_tracking_confidence
            )
            self.is_initialized = True
            return True
        except Exception as e:
            print(f"Error initializing face detector: {e}")
            return False
    
    def process_frame(self, frame: np.ndarray, timestamp_ms: float) -> List[FaceData]:
        """
        Process a frame with the face detector.
        
        Args:
            frame: Input frame as numpy array
            timestamp_ms: Timestamp of the frame in milliseconds
            
        Returns:
            List[FaceData]: List of detected faces with landmarks
        """
        if not self.is_initialized:
            if not self.initialize():
                return []
        
        # Convert the image to RGB
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        start_time = time.time()
        results = self.detector.process(image_rgb)
        process_time = (time.time() - start_time) * 1000  # Convert to ms
        
        # Update process times
        self.process_times.append(process_time)
        if len(self.process_times) > self.max_process_times:
            self.process_times.pop(0)
        
        # Extract face landmarks
        face_data_list = []
        
        if results.multi_face_landmarks:
            for i, face_landmarks in enumerate(results.multi_face_landmarks):
                # Convert landmarks to a list of dictionaries
                landmarks = []
                for landmark in face_landmarks.landmark:
                    landmarks.append({
                        'x': landmark.x,
                        'y': landmark.y,
                        'z': landmark.z,
                        'visibility': getattr(landmark, 'visibility', 1.0)
                    })
                
                # Extract visibility scores
                visibility = [lm.get('visibility', 1.0) for lm in landmarks]
                
                # Create face data
                face_data = FaceData(
                    landmarks=landmarks,
                    visibility=visibility,
                    timestamp=timestamp_ms,
                    detection_confidence=1.0,  # Face mesh doesn't provide confidence scores
                    tracking_id=i
                )
                
                # Add blendshapes if available
                if self.output_face_blendshapes and hasattr(results, 'face_blendshapes') and results.face_blendshapes:
                    if i < len(results.face_blendshapes):
                        blendshapes = []
                        for blendshape in results.face_blendshapes[i].categories:
                            blendshapes.append({
                                'name': blendshape.category_name,
                                'score': blendshape.score
                            })
                        face_data.blendshapes = blendshapes
                
                face_data_list.append(face_data)
        
        return face_data_list
    
    def draw_landmarks(self, frame: np.ndarray, results: List[FaceData]) -> np.ndarray:
        """
        Draw face landmarks on the frame.
        
        Args:
            frame: Input frame as numpy array
            results: List of FaceData objects
            
        Returns:
            np.ndarray: Frame with landmarks drawn
        """
        if not results:
            return frame
        
        # Create a copy of the frame
        annotated_frame = frame.copy()
        
        for face_data in results:
            # Convert landmarks to MediaPipe format
            face_landmarks_proto = self._convert_to_landmark_proto(face_data.landmarks)
            
            # Draw the face mesh
            self.mp_drawing.draw_landmarks(
                image=annotated_frame,
                landmark_list=face_landmarks_proto,
                connections=self.mp_face_mesh.FACEMESH_TESSELATION,
                landmark_drawing_spec=None,
                connection_drawing_spec=self.mp_drawing_styles.get_default_face_mesh_tesselation_style()
            )
            
            # Draw the face contours
            self.mp_drawing.draw_landmarks(
                image=annotated_frame,
                landmark_list=face_landmarks_proto,
                connections=self.mp_face_mesh.FACEMESH_CONTOURS,
                landmark_drawing_spec=None,
                connection_drawing_spec=self.mp_drawing_styles.get_default_face_mesh_contours_style()
            )
            
            # Draw the irises if refined landmarks are enabled
            if self.refine_landmarks:
                self.mp_drawing.draw_landmarks(
                    image=annotated_frame,
                    landmark_list=face_landmarks_proto,
                    connections=self.mp_face_mesh.FACEMESH_IRISES,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=self.mp_drawing_styles.get_default_face_mesh_iris_connections_style()
                )
        
        return annotated_frame
    
    def _convert_to_landmark_proto(self, landmarks: List[Dict[str, float]]) -> Any:
        """
        Convert landmarks from our format to MediaPipe's format.
        
        Args:
            landmarks: List of landmark dictionaries
            
        Returns:
            Any: MediaPipe landmark protocol buffer
        """
        landmark_list = mp.framework.formats.landmark_pb2.NormalizedLandmarkList()
        for lm in landmarks:
            landmark = landmark_list.landmark.add()
            landmark.x = lm['x']
            landmark.y = lm['y']
            landmark.z = lm['z']
            if 'visibility' in lm:
                landmark.visibility = lm['visibility']
        
        return landmark_list


class HandDetector(MediaPipeDetector):
    """
    MediaPipe hand landmark detector.
    Detects hand landmarks and handedness.
    """
    
    def __init__(
        self, 
        min_detection_confidence: float = 0.5, 
        min_tracking_confidence: float = 0.5,
        max_num_hands: int = 2,
        model_complexity: int = 1
    ):
        """
        Initialize the hand detector with specified parameters.
        
        Args:
            min_detection_confidence: Minimum confidence for detection to be considered successful
            min_tracking_confidence: Minimum confidence for tracking to be considered successful
            max_num_hands: Maximum number of hands to detect
            model_complexity: Model complexity (0, 1, or 2)
        """
        super().__init__(min_detection_confidence, min_tracking_confidence)
        self.max_num_hands = max_num_hands
        self.model_complexity = model_complexity
        
        # MediaPipe hands solution
        self.mp_hands = mp.solutions.hands
        self.mp_drawing_styles = mp.solutions.drawing_styles
    
    def initialize(self) -> bool:
        """
        Initialize the hand detector.
        
        Returns:
            bool: True if initialization was successful, False otherwise
        """
        try:
            self.detector = self.mp_hands.Hands(
                static_image_mode=False,
                max_num_hands=self.max_num_hands,
                model_complexity=self.model_complexity,
                min_detection_confidence=self.min_detection_confidence,
                min_tracking_confidence=self.min_tracking_confidence
            )
            self.is_initialized = True
            return True
        except Exception as e:
            print(f"Error initializing hand detector: {e}")
            return False
    
    def process_frame(self, frame: np.ndarray, timestamp_ms: float) -> List[HandData]:
        """
        Process a frame with the hand detector.
        
        Args:
            frame: Input frame as numpy array
            timestamp_ms: Timestamp of the frame in milliseconds
            
        Returns:
            List[HandData]: List of detected hands with landmarks
        """
        if not self.is_initialized:
            if not self.initialize():
                return []
        
        # Convert the image to RGB
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        start_time = time.time()
        results = self.detector.process(image_rgb)
        process_time = (time.time() - start_time) * 1000  # Convert to ms
        
        # Update process times
        self.process_times.append(process_time)
        if len(self.process_times) > self.max_process_times:
            self.process_times.pop(0)
        
        # Extract hand landmarks
        hand_data_list = []
        
        if results.multi_hand_landmarks and results.multi_handedness:
            for i, (hand_landmarks, handedness) in enumerate(zip(results.multi_hand_landmarks, results.multi_handedness)):
                # Convert landmarks to a list of dictionaries
                landmarks = []
                for landmark in hand_landmarks.landmark:
                    landmarks.append({
                        'x': landmark.x,
                        'y': landmark.y,
                        'z': landmark.z
                    })
                
                # Get handedness
                handedness_label = handedness.classification[0].label
                handedness_score = handedness.classification[0].score
                hand_flag = 1 if handedness_label == "Right" else 0
                
                # Create hand data
                hand_data = HandData(
                    landmarks=landmarks,
                    timestamp=timestamp_ms,
                    detection_confidence=handedness_score,
                    tracking_id=i,
                    handedness=handedness_label,
                    hand_flag=hand_flag
                )
                
                # Add world landmarks if available
                if hasattr(results, 'multi_hand_world_landmarks') and results.multi_hand_world_landmarks:
                    if i < len(results.multi_hand_world_landmarks):
                        world_landmarks = []
                        for landmark in results.multi_hand_world_landmarks[i].landmark:
                            world_landmarks.append({
                                'x': landmark.x,
                                'y': landmark.y,
                                'z': landmark.z
                            })
                        hand_data.world_landmarks = world_landmarks
                
                hand_data_list.append(hand_data)
        
        return hand_data_list
    
    def draw_landmarks(self, frame: np.ndarray, results: List[HandData]) -> np.ndarray:
        """
        Draw hand landmarks on the frame.
        
        Args:
            frame: Input frame as numpy array
            results: List of HandData objects
            
        Returns:
            np.ndarray: Frame with landmarks drawn
        """
        if not results:
            return frame
        
        # Create a copy of the frame
        annotated_frame = frame.copy()
        
        for hand_data in results:
            # Convert landmarks to MediaPipe format
            hand_landmarks_proto = self._convert_to_landmark_proto(hand_data.landmarks)
            
            # Draw the hand landmarks
            self.mp_drawing.draw_landmarks(
                image=annotated_frame,
                landmark_list=hand_landmarks_proto,
                connections=self.mp_hands.HAND_CONNECTIONS,
                landmark_drawing_spec=self.mp_drawing_styles.get_default_hand_landmarks_style(),
                connection_drawing_spec=self.mp_drawing_styles.get_default_hand_connections_style()
            )
            
            # Add handedness label
            height, width, _ = annotated_frame.shape
            x_min = min(lm['x'] for lm in hand_data.landmarks) * width
            y_min = min(lm['y'] for lm in hand_data.landmarks) * height
            cv2.putText(
                annotated_frame,
                f"{hand_data.handedness} ({hand_data.detection_confidence:.2f})",
                (int(x_min), int(y_min - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 255, 0),
                1,
                cv2.LINE_AA
            )
        
        return annotated_frame
    
    def _convert_to_landmark_proto(self, landmarks: List[Dict[str, float]]) -> Any:
        """
        Convert landmarks from our format to MediaPipe's format.
        
        Args:
            landmarks: List of landmark dictionaries
            
        Returns:
            Any: MediaPipe landmark protocol buffer
        """
        landmark_list = mp.framework.formats.landmark_pb2.NormalizedLandmarkList()
        for lm in landmarks:
            landmark = landmark_list.landmark.add()
            landmark.x = lm['x']
            landmark.y = lm['y']
            landmark.z = lm['z']
        
        return landmark_list


class PoseDetector(MediaPipeDetector):
    """
    MediaPipe pose landmark detector.
    Detects body pose landmarks.
    """
    
    def __init__(
        self, 
        min_detection_confidence: float = 0.5, 
        min_tracking_confidence: float = 0.5,
        model_complexity: int = 1,
        enable_segmentation: bool = False
    ):
        """
        Initialize the pose detector with specified parameters.
        
        Args:
            min_detection_confidence: Minimum confidence for detection to be considered successful
            min_tracking_confidence: Minimum confidence for tracking to be considered successful
            model_complexity: Model complexity (0, 1, or 2)
            enable_segmentation: Whether to enable segmentation
        """
        super().__init__(min_detection_confidence, min_tracking_confidence)
        self.model_complexity = model_complexity
        self.enable_segmentation = enable_segmentation
        
        # MediaPipe pose solution
        self.mp_pose = mp.solutions.pose
        self.mp_drawing_styles = mp.solutions.drawing_styles
    
    def initialize(self) -> bool:
        """
        Initialize the pose detector.
        
        Returns:
            bool: True if initialization was successful, False otherwise
        """
        try:
            self.detector = self.mp_pose.Pose(
                static_image_mode=False,
                model_complexity=self.model_complexity,
                enable_segmentation=self.enable_segmentation,
                min_detection_confidence=self.min_detection_confidence,
                min_tracking_confidence=self.min_tracking_confidence
            )
            self.is_initialized = True
            return True
        except Exception as e:
            print(f"Error initializing pose detector: {e}")
            return False
    
    def process_frame(self, frame: np.ndarray, timestamp_ms: float) -> List[PoseData]:
        """
        Process a frame with the pose detector.
        
        Args:
            frame: Input frame as numpy array
            timestamp_ms: Timestamp of the frame in milliseconds
            
        Returns:
            List[PoseData]: List of detected poses with landmarks
        """
        if not self.is_initialized:
            if not self.initialize():
                return []
        
        # Convert the image to RGB
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        start_time = time.time()
        results = self.detector.process(image_rgb)
        process_time = (time.time() - start_time) * 1000  # Convert to ms
        
        # Update process times
        self.process_times.append(process_time)
        if len(self.process_times) > self.max_process_times:
            self.process_times.pop(0)
        
        # Extract pose landmarks
        pose_data_list = []
        
        if results.pose_landmarks:
            # Convert landmarks to a list of dictionaries
            landmarks = []
            visibility = []
            for landmark in results.pose_landmarks.landmark:
                landmarks.append({
                    'x': landmark.x,
                    'y': landmark.y,
                    'z': landmark.z,
                    'visibility': landmark.visibility
                })
                visibility.append(landmark.visibility)
            
            # Create pose data
            pose_data = PoseData(
                landmarks=landmarks,
                visibility=visibility,
                timestamp=timestamp_ms,
                detection_confidence=1.0,  # Pose doesn't provide overall confidence scores
                tracking_id=0
            )
            
            # Add world landmarks if available
            if results.pose_world_landmarks:
                world_landmarks = []
                for landmark in results.pose_world_landmarks.landmark:
                    world_landmarks.append({
                        'x': landmark.x,
                        'y': landmark.y,
                        'z': landmark.z,
                        'visibility': landmark.visibility
                    })
                pose_data.world_landmarks = world_landmarks
            
            # Add segmentation mask if enabled
            if self.enable_segmentation and results.segmentation_mask is not None:
                pose_data.segmentation_mask = results.segmentation_mask
            
            pose_data_list.append(pose_data)
        
        return pose_data_list
    
    def draw_landmarks(self, frame: np.ndarray, results: List[PoseData]) -> np.ndarray:
        """
        Draw pose landmarks on the frame.
        
        Args:
            frame: Input frame as numpy array
            results: List of PoseData objects
            
        Returns:
            np.ndarray: Frame with landmarks drawn
        """
        if not results:
            return frame
        
        # Create a copy of the frame
        annotated_frame = frame.copy()
        
        for pose_data in results:
            # Convert landmarks to MediaPipe format
            pose_landmarks_proto = self._convert_to_landmark_proto(pose_data.landmarks)
            
            # Draw the pose landmarks
            self.mp_drawing.draw_landmarks(
                image=annotated_frame,
                landmark_list=pose_landmarks_proto,
                connections=self.mp_pose.POSE_CONNECTIONS,
                landmark_drawing_spec=self.mp_drawing_styles.get_default_pose_landmarks_style()
            )
            
            # Draw segmentation mask if available
            if self.enable_segmentation and pose_data.segmentation_mask is not None:
                segmentation_mask = pose_data.segmentation_mask
                
                # Create a colored mask
                bg_image = np.zeros(annotated_frame.shape, dtype=np.uint8)
                bg_image[:] = (192, 192, 192)  # Light gray background
                
                condition = np.stack((segmentation_mask,) * 3, axis=-1) > 0.1
                annotated_frame = np.where(condition, annotated_frame, bg_image)
        
        return annotated_frame
    
    def _convert_to_landmark_proto(self, landmarks: List[Dict[str, float]]) -> Any:
        """
        Convert landmarks from our format to MediaPipe's format.
        
        Args:
            landmarks: List of landmark dictionaries
            
        Returns:
            Any: MediaPipe landmark protocol buffer
        """
        landmark_list = mp.framework.formats.landmark_pb2.NormalizedLandmarkList()
        for lm in landmarks:
            landmark = landmark_list.landmark.add()
            landmark.x = lm['x']
            landmark.y = lm['y']
            landmark.z = lm['z']
            if 'visibility' in lm:
                landmark.visibility = lm['visibility']
        
        return landmark_list


class MediaPipeProcessor:
    """
    Main processor class that combines all MediaPipe detectors.
    Handles video capture and processing with all detectors.
    """
    
    def __init__(
        self,
        enable_face: bool = True,
        enable_hands: bool = True,
        enable_pose: bool = True,
        camera_index: int = 0,
        width: int = 640,
        height: int = 480,
        fps: int = 30
    ):
        """
        Initialize the MediaPipe processor with specified parameters.
        
        Args:
            enable_face: Whether to enable face detection
            enable_hands: Whether to enable hand detection
            enable_pose: Whether to enable pose detection
            camera_index: Index of the camera to use
            width: Desired frame width
            height: Desired frame height
            fps: Desired frames per second
        """
        self.enable_face = enable_face
        self.enable_hands = enable_hands
        self.enable_pose = enable_pose
        
        # Initialize video capture
        self.video_manager = get_video_manager()
        self.capture = self.video_manager.get_capture(camera_index)
        self.capture.width = width
        self.capture.height = height
        self.capture.fps = fps
        
        # Initialize detectors
        self.face_detector = FaceDetector() if enable_face else None
        self.hand_detector = HandDetector() if enable_hands else None
        self.pose_detector = PoseDetector() if enable_pose else None
        
        # Processing state
        self.is_processing = False
        self.frame_count = 0
        self.last_result = None
        self.result_callback = None
        
        # Performance metrics
        self.start_time = 0
        self.process_times = []
        self.max_process_times = 30
    
    def start(self) -> bool:
        """
        Start video capture and processing.
        
        Returns:
            bool: True if successfully started, False otherwise
        """
        if self.is_processing:
            return True
        
        # Initialize detectors
        if self.enable_face and self.face_detector:
            self.face_detector.initialize()
        
        if self.enable_hands and self.hand_detector:
            self.hand_detector.initialize()
        
        if self.enable_pose and self.pose_detector:
            self.pose_detector.initialize()
        
        # Start video capture
        if not self.capture.start():
            print("Failed to start video capture")
            return False
        
        # Add frame callback
        self.capture.add_frame_callback(self._process_frame_callback)
        
        self.is_processing = True
        self.start_time = time.time()
        self.frame_count = 0
        
        return True
    
    def stop(self) -> None:
        """Stop video capture and processing."""
        if not self.is_processing:
            return
        
        # Remove frame callback
        self.capture.remove_frame_callback(self._process_frame_callback)
        
        # Stop video capture
        self.capture.stop()
        
        # Close detectors
        if self.face_detector:
            self.face_detector.close()
        
        if self.hand_detector:
            self.hand_detector.close()
        
        if self.pose_detector:
            self.pose_detector.close()
        
        self.is_processing = False
    
    def _process_frame_callback(self, frame: np.ndarray, timestamp_ms: float) -> None:
        """
        Process a frame with all enabled detectors.
        
        Args:
            frame: Input frame as numpy array
            timestamp_ms: Timestamp of the frame in milliseconds
        """
        start_time = time.time()
        
        # Process with each detector
        face_results = []
        hand_results = []
        pose_results = []
        
        if self.enable_face and self.face_detector:
            face_results = self.face_detector.process_frame(frame, timestamp_ms)
        
        if self.enable_hands and self.hand_detector:
            hand_results = self.hand_detector.process_frame(frame, timestamp_ms)
        
        if self.enable_pose and self.pose_detector:
            pose_results = self.pose_detector.process_frame(frame, timestamp_ms)
        
        # Create detection result
        result = DetectionResult(
            faces=face_results,
            hands=hand_results,
            pose=pose_results,
            frame_timestamp=timestamp_ms,
            frame_index=self.frame_count,
            source_dimensions=(frame.shape[1], frame.shape[0])
        )
        
        # Update state
        self.last_result = result
        self.frame_count += 1
        
        # Calculate process time
        process_time = (time.time() - start_time) * 1000  # Convert to ms
        self.process_times.append(process_time)
        if len(self.process_times) > self.max_process_times:
            self.process_times.pop(0)
        
        # Call result callback if set
        if self.result_callback:
            try:
                self.result_callback(result)
            except Exception as e:
                print(f"Error in result callback: {e}")
    
    def get_last_result(self) -> Optional[DetectionResult]:
        """
        Get the last detection result.
        
        Returns:
            Optional[DetectionResult]: Last detection result or None if not available
        """
        return self.last_result
    
    def set_result_callback(self, callback: Callable[[DetectionResult], None]) -> None:
        """
        Set a callback function that will be called for each detection result.
        
        Args:
            callback: Function that takes a DetectionResult as argument
        """
        self.result_callback = callback
    
    def draw_landmarks(self, frame: np.ndarray) -> np.ndarray:
        """
        Draw all landmarks on the frame.
        
        Args:
            frame: Input frame as numpy array
            
        Returns:
            np.ndarray: Frame with landmarks drawn
        """
        if self.last_result is None:
            return frame
        
        # Create a copy of the frame
        annotated_frame = frame.copy()
        
        # Draw face landmarks
        if self.enable_face and self.face_detector and self.last_result.faces:
            annotated_frame = self.face_detector.draw_landmarks(annotated_frame, self.last_result.faces)
        
        # Draw hand landmarks
        if self.enable_hands and self.hand_detector and self.last_result.hands:
            annotated_frame = self.hand_detector.draw_landmarks(annotated_frame, self.last_result.hands)
        
        # Draw pose landmarks
        if self.enable_pose and self.pose_detector and self.last_result.pose:
            annotated_frame = self.pose_detector.draw_landmarks(annotated_frame, self.last_result.pose)
        
        return annotated_frame
    
    def get_average_process_time(self) -> float:
        """
        Get the average processing time in milliseconds.
        
        Returns:
            float: Average processing time in milliseconds
        """
        if not self.process_times:
            return 0.0
        return sum(self.process_times) / len(self.process_times)
    
    def get_fps(self) -> float:
        """
        Get the current processing FPS.
        
        Returns:
            float: Current processing FPS
        """
        if not self.process_times:
            return 0.0
        avg_process_time = self.get_average_process_time()
        if avg_process_time <= 0:
            return 0.0
        return 1000.0 / avg_process_time
    
    def is_available(self) -> bool:
        """
        Check if all required components are available.
        
        Returns:
            bool: True if all required components are available, False otherwise
        """
        # Check camera availability
        camera_available = self.capture.is_available()
        
        # Check detector availability
        face_available = not self.enable_face or (self.face_detector and self.face_detector.is_initialized)
        hands_available = not self.enable_hands or (self.hand_detector and self.hand_detector.is_initialized)
        pose_available = not self.enable_pose or (self.pose_detector and self.pose_detector.is_initialized)
        
        return camera_available and face_available and hands_available and pose_available
    
    def __del__(self):
        """Ensure resources are released when object is destroyed."""
        self.stop()


# Global MediaPipe processor instance
mediapipe_processor = None

def get_mediapipe_processor() -> MediaPipeProcessor:
    """
    Get the global MediaPipe processor instance.
    Creates a new instance if one doesn't exist.
    
    Returns:
        MediaPipeProcessor: Global MediaPipe processor instance
    """
    global mediapipe_processor
    if mediapipe_processor is None:
        mediapipe_processor = MediaPipeProcessor()
    return mediapipe_processor


if __name__ == "__main__":
    """Test the MediaPipe processor functionality."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Test MediaPipe processor")
    parser.add_argument("--camera", type=int, default=0, help="Camera index")
    parser.add_argument("--width", type=int, default=640, help="Frame width")
    parser.add_argument("--height", type=int, default=480, help="Frame height")
    parser.add_argument("--fps", type=int, default=30, help="Target FPS")
    parser.add_argument("--no-face", action="store_true", help="Disable face detection")
    parser.add_argument("--no-hands", action="store_true", help="Disable hand detection")
    parser.add_argument("--no-pose", action="store_true", help="Disable pose detection")
    args = parser.parse_args()
    
    # Create and start MediaPipe processor
    processor = MediaPipeProcessor(
        enable_face=not args.no_face,
        enable_hands=not args.no_hands,
        enable_pose=not args.no_pose,
        camera_index=args.camera,
        width=args.width,
        height=args.height,
        fps=args.fps
    )
    
    if not processor.start():
        print("Failed to start MediaPipe processor")
        exit(1)
    
    try:
        print("Press ESC to exit")
        while True:
            # Get the current frame
            frame, timestamp = processor.capture.get_frame()
            if frame is None:
                time.sleep(0.01)
                continue
            
            # Draw landmarks on the frame
            annotated_frame = processor.draw_landmarks(frame)
            
            # Display performance metrics
            fps = processor.get_fps()
            avg_process_time = processor.get_average_process_time()
            cv2.putText(annotated_frame, f"FPS: {fps:.1f}", (10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(annotated_frame, f"Process time: {avg_process_time:.1f} ms", (10, 70), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            # Display the frame
            cv2.imshow("MediaPipe Processor Test", annotated_frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC key
                break
    
    finally:
        processor.stop()
        cv2.destroyAllWindows()
